import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  img =  'etaougas.jpg';
  res = 0;
  gas = 0;
  eta = 0;
  constructor() {}

  abtc = [
    'Etanol', 'Gasolina', 'Sua escolha',
  ]
  respcal = '';

  conta(): void{
    this.res = this.eta / this.gas;
    if(this.res >= 0.7){
      this.img = 'gas.jpg'; this.respcal = this.abtc[1];
    }else if (this.res <= 0.7){
      this.img = 'eta.jpg'; this.respcal = this.abtc[0];
    }else{
      this.img = 'tantofaz.jpg'; this.respcal = this.abtc[2];
    }
  }
}
