import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  login    = ''
  senha    = ''
  resposta = ''

  constructor() {}

  validar(): void{
    if(this.login === 'admin' && this.senha === '123'){
      this.resposta = 'Usuário logado com sucesso'
    }else{
      this.resposta = 'Login ou senha incorretos'
    }
  }

}
